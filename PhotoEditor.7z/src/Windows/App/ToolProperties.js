import React from 'react'
import './ToolProperties.less'

const ToolProperties = ()=>{
    return(
        <div className={`tool-properties-container`}>
            <div className={`options-bar`}></div>
        </div>
    )
}

export default ToolProperties